# This file is executed on every boot (including wake-boot from deepsleep)

import sys
sys.path[1] = "/flash/lib"